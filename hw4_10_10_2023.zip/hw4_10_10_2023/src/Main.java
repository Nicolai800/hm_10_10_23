import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Пользователь вводит целое число. Напишите программу, которая делит это число на 2 и выводит результат.
        // Остаток деления можно отбросить. Операторы деления /, умножения * и остатка от деления % применять нельзя.

        System.out.println("Введите целое число ");
        Scanner scr = new Scanner(System.in);
        int a = scr.nextInt();
        int c = a >> 1;
        System.out.println(c);
    }
}