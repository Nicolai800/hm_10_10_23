public class Main {
    public static void main(String[] args) {
        //Когда закончится учебный год (isYearFinished) и если будет солнечная погода (isGoodWeather),
        // то ребята пойдут в поход. Если туркружок закупит дождевики (hasBoughtRaincoats) к концу учебного года,
        // то ребята пойдут в поход даже в плохую погоду. В поход ребят должен кто-то повести. Поведёт тренер Джим,
        // если он освободится от сдачи тренерского экзамена (isJimFree), или тренер Кейт,
        // если она вернётся из путешествия (hasKateComeBack). Вести детей может только один тренер.
        // Если Джим и Кейт смогут вести детей вместе, то они обязательно поссорятся из-за этого и никто никуда не пойдёт.
        boolean isYearFinished = true;
        boolean isGoodWeather = false;
        boolean hasBoughtRaincoats = true;
        boolean isJimFree = true;
        boolean hasKateComeBack = false;
        boolean theHikeWillTakePlace = isYearFinished && (isGoodWeather || hasBoughtRaincoats) && (isJimFree ^ hasKateComeBack);
        System.out.println(theHikeWillTakePlace);
    }
}