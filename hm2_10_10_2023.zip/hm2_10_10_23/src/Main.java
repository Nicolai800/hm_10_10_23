import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь-продавец вводит суммарную стоимость покупок и сумму денег,
        // которую дал покупатель. Выведите сумму сдачи в виде “X рублей и Y копеек”.
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите суммарную стоимость покупок");
        double cost = scr.nextDouble();
        System.out.println("Введите сумму полученную от покупателя");
        double sum = scr.nextDouble();
        double change = sum - cost;
        int x = (int) (change/1);
        int y = (int) ((change*100)%100);
        System.out.println("Сумма сдачи равна "+x+" рублей "+y+" копеек");

    }
}