
public class HomeWork {
    public static void main(String[] args) {
        // Дана длина в метрах. Напишите программу, которая переводит указанное значение в км, мили, футы и аршины.
        // Выведите начальное и конвертированные значения на экран.
        double m = 2345;
        System.out.println("Длина в метрах равна "+ m);
        double km = m/1000;
        System.out.println("Длина в километрах равна "+ km);
        double ml = m/1609.34;
        System.out.println("Длина в милях равна "+ml);
        double ft = m*3.281;
        System.out.println("Длина в футах равна "+ft);
        double arsh = m/0.7112;
        System.out.println("Длина в аршинах равна "+ arsh);

    }
}
